<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm fixed-bottom mt-5">
     <a class="navbar-brand mx-auto" href="<?php echo e(url('/')); ?>">
         <img src="<?php echo e(asset('img/logo.jpg')); ?>" class="img-fluid">
     </a>
 </nav><?php /**PATH C:\xampp\htdocs\laravel-samuraimart\resources\views/components/footer.blade.php ENDPATH**/ ?>